from Crypto.Util.number import bytes_to_long, getPrime
import sympy
import random


flag = '***REDACTED***'.encode('utf-8')
e = 0x10001
upin = getPrime(1024)
ipin = sympy.nextprime(upin)
cipher = (pow(bytes_to_long(flag), e, upin*ipin))
print('n =', upin*ipin)
print('e =', e)
print('cipher =', cipher)
